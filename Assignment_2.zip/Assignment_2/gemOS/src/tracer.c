#include<context.h>
#include<memory.h>
#include<lib.h>
#include<entry.h>
#include<file.h>
#include<tracer.h>


///////////////////////////////////////////////////////////////////////////
//// 		Start of Trace buffer functionality 		      /////
///////////////////////////////////////////////////////////////////////////

int is_valid_mem_range(unsigned long buff, u32 count, int access_bit) {
    // To get the current execution context
    struct exec_context *current = get_current_ctx();
    struct mm_segment *mm = current->mms;
    // For iterating through memory segments
    for (int i = 0; i < MAX_MM_SEGS; i++) {
        if (buff >= mm[i].start && buff + count <= mm[i].end) {
            // Checking the access bit
            if (access_bit & 1 && (mm[i].access_flags & MM_RD) == MM_RD) {
                return 0;  // Valid buffer for reading
            } else if (((access_bit & (1 << 1)) != 0) && (mm[i].access_flags & MM_WR) == MM_WR) {
                return 0;  // Valid buffer for writing
            } else {
                return -EBADMEM;  // Invalid buffer due to access permissions
            }
        }
    }
    // To iterate through vm_areas
    struct vm_area *vma = current->vm_area;
    while (vma != NULL) {
        if (buff >= vma->vm_start && buff + count <= vma->vm_end) {
            // Checking the access bit
            if (access_bit & 1 && (vma->access_flags & MM_RD) == MM_RD) {
                return 0;  // Valid buffer for reading
            } else if (((access_bit & (1 << 1)) != 0) && (vma->access_flags & MM_WR) == MM_WR) {
                return 0;  // Valid buffer for writing
            } else {
                return -EBADMEM;  // Invalid buffer due to access permissions
            }
        }
        vma = vma->vm_next;
    }
    return -EBADMEM;  // Invalid buffer (not within any valid memory segment or vm_area)
}



long trace_buffer_close(struct file *filep) {
    // To decrease the reference count of the file object
    if (filep->ref_count > 0) {
        filep->ref_count--;

        // To check if the reference count has reached zero
        if (filep->ref_count == 0) {
            // Free resources associated with the trace buffer
            if (filep->trace_buffer) {
                // Deallocate memory for the trace buffer
                os_page_free(USER_REG, filep->trace_buffer);
                filep->trace_buffer = NULL;
            }

            // Deallocate memory for fileops 
            if (filep->fops) {
                os_free(filep->fops, sizeof(struct fileops));
                filep->fops = NULL;
            }

            // Deallocate memory for the file object
            os_free(filep, sizeof(struct file));
        }
    }

    return 0; // Return success
}


int trace_buffer_read(struct file *filep, char *buff, u32 count) {
    // To check if the file  allows read access
    if (!(filep->mode & O_READ)) {
        return -EINVAL; // File is not open for reading
    }

    // To check if the count is valid
    if (count <= 0) {
        return -EINVAL; // Invalid count
    }

    // Get a pointer to the trace buffer associated with the file
    struct trace_buffer_info *trace_buffer = filep->trace_buffer;

    // To check if the trace buffer is valid
    if (!trace_buffer) {
        return -EINVAL; // Invalid trace buffer
    }
    
    
    // To call the is_valid_mem_range function to check buffer validity
    int access_bit = MM_WR; // For reading
    int buffer_validity = is_valid_mem_range((unsigned long)buff, count, access_bit);

    if (buffer_validity != 0) {
        return buffer_validity; // Buffer is not valid
    }

    
    // To calculate the number of bytes available for reading
    u32 bytes_available;

    if (trace_buffer->W >= trace_buffer->R) {
        bytes_available = trace_buffer->W - trace_buffer->R;
    } else {
        bytes_available = TRACE_BUFFER_MAX_SIZE - trace_buffer->R + trace_buffer->W;
    }

    // To check if there's no data available for reading
    if (bytes_available == 0) {
        return 0;
    }

    // Calculate the number of bytes to read (limited by available bytes)
    u32 bytes_to_read = (count < bytes_available) ? count : bytes_available;

    // Perform the read in two parts if wrap-around is needed
    if (trace_buffer->R + bytes_to_read > TRACE_BUFFER_MAX_SIZE) {
        u32 bytes_to_read_part1 = TRACE_BUFFER_MAX_SIZE - trace_buffer->R;

        // Pointer to the source location in the trace buffer (part 1)
        char *src_part1 = trace_buffer->data + trace_buffer->R;

        // Copy data from the trace buffer to the user buffer (part 1)
        for (u32 i = 0; i < bytes_to_read_part1; i++) {
            buff[i] = src_part1[i];
        }

        // Calculate the remaining bytes to read
        u32 bytes_to_read_part2 = bytes_to_read - bytes_to_read_part1;

        // Pointer to the source location in the trace buffer (part 2)
        char *src_part2 = trace_buffer->data;

        // Copy the remaining data from the trace buffer to the user buffer (part 2)
        for (u32 i = 0; i < bytes_to_read_part2; i++) {
            buff[bytes_to_read_part1 + i] = src_part2[i];
        }

        // Update the read offset after the wrap-around read
        trace_buffer->R = (trace_buffer->R + bytes_to_read_part2) % TRACE_BUFFER_MAX_SIZE;
    } else {
        // Normal read, where the entire data can be read without wrap-around
        char *src = trace_buffer->data + trace_buffer->R;

        // Copy data from the trace buffer to the user buffer
        for (u32 i = 0; i < bytes_to_read; i++) {
            buff[i] = src[i];
        }

        // Update the read offset
        trace_buffer->R = (trace_buffer->R + bytes_to_read) % TRACE_BUFFER_MAX_SIZE;
    }

    return bytes_to_read; // Return the number of bytes read
}


int trace_buffer_write(struct file *filep, char *buff, u32 count) {
    // Check if the file mode allows write access
    if (!(filep->mode & O_WRITE)) {
        return -EINVAL; // File is not open for writing
    }
    // Check if the count is valid
    if (count <= 0) {
        return -EINVAL; // Invalid count
    }
    // Get a pointer to the trace buffer associated with the file
    struct trace_buffer_info *trace_buffer = filep->trace_buffer;

    // Check if the trace buffer is valid
    if (!trace_buffer) {
        return -EINVAL; // Invalid trace buffer
    }
   
    //Call the is_valid_mem_range function to check buffer validity
    int access_bit = MM_RD; // For writing
    int buffer_validity = is_valid_mem_range((unsigned long)buff, count, access_bit);

    if (buffer_validity != 0) {
        return buffer_validity; // Buffer is not valid
    }
    
    // Calculate the available space from the current write offset to the end of the buffer
    u32 available_space = TRACE_BUFFER_MAX_SIZE - trace_buffer->W;

    // Check if a wrap-around write is needed
    if (count > available_space) {
        // Perform the write in two parts: first, from the current write offset to the end of the buffer
        u32 bytes_to_write_part1 = available_space;

        // Pointer to the destination location in the trace buffer (part 1)
        char *dest_part1 = trace_buffer->data + trace_buffer->W;

        // Copy data from the user buffer (buff) to the trace buffer (part 1)
        for (u32 i = 0; i < bytes_to_write_part1; i++) {
            dest_part1[i] = buff[i];
        }

        // Update the write offset
        trace_buffer->W = 0;

        // Calculate the remaining bytes to write
        u32 bytes_to_write_part2 = count - bytes_to_write_part1;

        // Pointer to the destination location in the trace buffer (part 2)
        char *dest_part2 = trace_buffer->data;

        // Copy the remaining data from the user buffer to the trace buffer (part 2)
        for (u32 i = 0; i < bytes_to_write_part2; i++) {
            dest_part2[i] = buff[i + bytes_to_write_part1];
        }

        // Update the write offset after the wrap-around write
        trace_buffer->W = bytes_to_write_part2;
        return count; // Return the number of bytes written
    } else {
        // Normal write, where the entire data can be written without wrap-around
        char *dest = trace_buffer->data + trace_buffer->W;

        // Copy data from the user buffer (buff) to the trace buffer
        for (u32 i = 0; i < count; i++) {
            dest[i] = buff[i];
        }

        // Update the write offset
        trace_buffer->W += count;
        return count; // Return the number of bytes written
    }
}



int sys_create_trace_buffer(struct exec_context *current, int mode) {
    if (current == NULL) {
        return -EINVAL; // Invalid exec context
    }
    // Find a free file descriptor for the trace buffer
    int fd;
    for (fd = 0; fd < MAX_OPEN_FILES; fd++) {
        if (current->files[fd] == NULL) {
            break;
        }
    }
    if (fd >= MAX_OPEN_FILES) {
        return -EINVAL; // No free file descriptor available
    }
    // Allocate memory for the file object
    struct file *filep = (struct file *)os_page_alloc(USER_REG);
    if (filep == NULL) {
        return -ENOMEM; // Memory allocation failed
    }
    // Initialize the file object
    filep->type = TRACE_BUFFER;
    filep->mode = mode;
    filep->offp = 0;
    filep->ref_count = 1; // Initially set to 1
    filep->inode = NULL; // Trace buffer does not have an inode
    filep->trace_buffer = NULL; // Allocate the trace buffer later
    filep->fops = NULL; // Allocate fileops later

    // Now, allocate memory for the trace buffer info
    struct trace_buffer_info *tb_info = (struct trace_buffer_info *)os_page_alloc(USER_REG);
    if (tb_info == NULL) {
        os_page_free(USER_REG, filep);
        return -ENOMEM; // Memory allocation failed
    }
    // Initialize the trace buffer info
    tb_info->mode = mode;
    tb_info->R = 0;
    tb_info->W = 0;

    // Set the trace buffer in the file object
    filep->trace_buffer = tb_info;

    // Allocate memory for the fileops object and assign the read, write, and close handlers
    struct fileops *fops = (struct fileops *)os_alloc(sizeof(struct fileops));
    if (fops == NULL) {
        os_free(tb_info, sizeof(struct trace_buffer_info));
        os_page_free(USER_REG, filep);
        return -ENOMEM; // Memory allocation failed
    }
    fops->read = trace_buffer_read;
    fops->write = trace_buffer_write;
    fops->lseek = NULL; // No seek operation supported
    fops->close = trace_buffer_close;

    // Set the fileops in the file object
    filep->fops = fops;

    // Set the file object in the current exec context
    current->files[fd] = filep;
    // Return the allocated file descriptor
    return fd;
}




///////////////////////////////////////////////////////////////////////////
//// 		Start of strace functionality 		      	      /////
///////////////////////////////////////////////////////////////////////////

// Initialize data structure for the list of traced system calls
struct strace_info *traced_syscalls = NULL;

// Initialize the trace buffer
struct trace_buffer_info trace_buffer = {
    .mode = 0,  // Initialize the mode (FULL TRACING or FILTERED TRACING)
    .R = 0,     // Read offset
    .W = 0      // Write offset
};

// Function to write data to the trace buffer
int write_trace_buffer(char *data, u64 size) {
    if (trace_buffer.W + size > TRACE_BUFFER_MAX_SIZE) {
        return -ENOMEM; // Trace buffer is full
    }

    // Copy data to the trace buffer manually using a loop
    for (u32 i = 0; i < size; i++) {
        trace_buffer.data[trace_buffer.W + i] = data[i];
    }
    trace_buffer.W += size;

    return 0; // On success
}

int num_of_arguments(u64 syscall_num){
        switch(syscall_num){
                case 2:
                case 10:
                case 11:
                case 13:
                case 15:
                case 20:
                case 21:
                case 22:
                case 38:
                case 61:
                        return 0;
                case 1:
                case 6:
                case 7:
                case 12:
                case 14:
                case 19:
                case 27:
                case 29:
                case 36:
                        return 1;
                case 4:
                case 8:
                case 9:
                case 17:
                case 28:
                case 37:
                case 40:
                        return 2;
                case 5:
                case 18:
                case 24:
                case 25:
                case 30:
                case 39:
                case 41:
                        return 3;
                case 16:
                case 23:
                case 35:
                        return 4;
                default:
                        return 0;
        }
        return 0;
}
	

int perform_tracing(u64 syscall_num, u64 param1, u64 param2, u64 param3, u64 param4)
{    struct exec_context *current = get_current_ctx();
      int found = 0;
     if(!current){
	return -EINVAL;
     }
     if(!current->st_md_base) {
        // return -EINVAL; // Invalid context or data structures
        current->st_md_base = os_alloc(sizeof(struct strace_head));
        if(current->st_md_base == NULL){
		return -EINVAL;
	}
//	current->st_md_base->
        return 0;
    }
    
    if(syscall_num == SYSCALL_END_STRACE){
		return 0;
	}

    // Copy data to the trace buffer manually using a loop
    struct file *filep = current->files[current->st_md_base->strace_fd];

    if (current->st_md_base->tracing_mode == FULL_TRACING) {

        // Check if there is enough space in the trace buffer
        if (filep->trace_buffer->W + 5 * sizeof(u64) > TRACE_BUFFER_MAX_SIZE) {
            return -EINVAL; // Trace buffer full
        }
        // Write the system call information to the trace buffer
        
        if (syscall_num == SYSCALL_FORK || syscall_num == SYSCALL_GETPID ||
            syscall_num == SYSCALL_STATS || syscall_num == SYSCALL_CFORK ||
            syscall_num == SYSCALL_PHYS_INFO || syscall_num == SYSCALL_VFORK ||
            syscall_num == SYSCALL_GET_USER_P || syscall_num == SYSCALL_GET_COW_F ||
            syscall_num == SYSCALL_GETPPID || 
            syscall_num == SYSCALL_END_STRACE) {   // No. of parameters = 0
            if (filep->trace_buffer->W + sizeof(u64) > TRACE_BUFFER_MAX_SIZE) {
                return -EINVAL; // Trace buffer full
            }
            // Write the system call number to the trace buffer
            *(u64 *)(filep->trace_buffer->data + filep->trace_buffer->W) = syscall_num;

            // Update the write pointer
            filep->trace_buffer->W = (filep->trace_buffer->W + sizeof(u64)) % TRACE_BUFFER_MAX_SIZE;
        } else if (syscall_num == SYSCALL_CLOSE || syscall_num == SYSCALL_EXIT ||
                   syscall_num == SYSCALL_SLEEP || syscall_num == SYSCALL_CONFIGURE ||
                   syscall_num == SYSCALL_DUMP_PTT || syscall_num == SYSCALL_PMAP ||
                   syscall_num == SYSCALL_DUP || syscall_num == SYSCALL_TRACE_BUFFER ||
                   syscall_num == SYSCALL_ALARM) {                                     // No. of parameters = 1
            if (filep->trace_buffer->W + 2 * sizeof(u64) > TRACE_BUFFER_MAX_SIZE) {
                return -EINVAL; // Trace buffer full
            }
            // Write the system call number and parameter 1 to the trace buffer
            *(u64 *)(filep->trace_buffer->data + filep->trace_buffer->W) = syscall_num;
            *(u64 *)(filep->trace_buffer->data + filep->trace_buffer->W + sizeof(u64)) = param1;
            // Update the write pointer
            filep->trace_buffer->W = (filep->trace_buffer->W + 2 * sizeof(u64)) % TRACE_BUFFER_MAX_SIZE;
        } else if (syscall_num == SYSCALL_EXPAND || 
                   syscall_num == SYSCALL_SIGNAL || syscall_num == SYSCALL_CLONE ||
                   syscall_num == SYSCALL_MUNMAP || syscall_num == SYSCALL_DUP2 ||
                   syscall_num == SYSCALL_STRACE || syscall_num == SYSCALL_START_STRACE ) {   // No. of parameters = 2
            if (filep->trace_buffer->W + 3 * sizeof(u64) > TRACE_BUFFER_MAX_SIZE) {
                return -EINVAL; // Trace buffer full
            }
            // Write the system call number, parameter 1, and parameter 2 to the trace buffer
            *(u64 *)(filep->trace_buffer->data + filep->trace_buffer->W) = syscall_num;
            *(u64 *)(filep->trace_buffer->data + filep->trace_buffer->W + sizeof(u64)) = param1;
            *(u64 *)(filep->trace_buffer->data + filep->trace_buffer->W + 2 * sizeof(u64)) = param2;
            // Update the write pointer
            filep->trace_buffer->W = (filep->trace_buffer->W + 3 * sizeof(u64)) % TRACE_BUFFER_MAX_SIZE;
        } else if (syscall_num == SYSCALL_READ || syscall_num == SYSCALL_MPROTECT ||
                   syscall_num == SYSCALL_WRITE || syscall_num == SYSCALL_LSEEK ||
                   syscall_num == SYSCALL_READ_STRACE || syscall_num == SYSCALL_READ_FTRACE ||
                   syscall_num == SYSCALL_SHRINK) {   // No. of parameters = 3
            if (filep->trace_buffer->W + 4 * sizeof(u64) > TRACE_BUFFER_MAX_SIZE) {
                return -EINVAL; // Trace buffer full
            }
            // Write the system call number, parameter 1, parameter 2, and parameter 3 to the trace buffer
            *(u64 *)(filep->trace_buffer->data + filep->trace_buffer->W) = syscall_num;
            *(u64 *)(filep->trace_buffer->data + filep->trace_buffer->W + sizeof(u64)) = param1;
            *(u64 *)(filep->trace_buffer->data + filep->trace_buffer->W + 2 * sizeof(u64)) = param2;
            *(u64 *)(filep->trace_buffer->data + filep->trace_buffer->W + 3 * sizeof(u64)) = param3;
            // Update the write pointer
            filep->trace_buffer->W = (filep->trace_buffer->W + 4 * sizeof(u64)) % TRACE_BUFFER_MAX_SIZE;
        } else if (syscall_num == SYSCALL_MMAP || syscall_num == SYSCALL_FTRACE || 
        	   syscall_num == SYSCALL_OPEN ) {                                           // No. of parameters = 4
            if (filep->trace_buffer->W + 5 * sizeof(u64) > TRACE_BUFFER_MAX_SIZE) {
                return -EINVAL; // Trace buffer full
            }
            // Write the system call number, parameter 1, parameter 2, and parameter 3 to the trace buffer
            *(u64 *)(filep->trace_buffer->data + filep->trace_buffer->W) = syscall_num;
            *(u64 *)(filep->trace_buffer->data + filep->trace_buffer->W + sizeof(u64)) = param1;
            *(u64 *)(filep->trace_buffer->data + filep->trace_buffer->W + 2 * sizeof(u64)) = param2;
            *(u64 *)(filep->trace_buffer->data + filep->trace_buffer->W + 3 * sizeof(u64)) = param3;
            *(u64 *)(filep->trace_buffer->data + filep->trace_buffer->W + 4 * sizeof(u64)) = param4;
            // Update the write pointer
            filep->trace_buffer->W = (filep->trace_buffer->W + 5 * sizeof(u64)) % TRACE_BUFFER_MAX_SIZE;
        }
        
        
        
    } else {
        // Implement the logic for FILTERED TRACING mode       
        // check if syscall_num is found in current->st_md_base->next 
        struct strace_info* CURR = current->st_md_base->next;
        // Check if the given syscall exists in the list of traced system calls
        // If found, store the information in the trace buffer and update the write pointer
        // Set the 'found' flag accordingly
        if (syscall_num == SYSCALL_FORK || syscall_num == SYSCALL_GETPID ||
            syscall_num == SYSCALL_STATS || syscall_num == SYSCALL_CFORK ||
            syscall_num == SYSCALL_PHYS_INFO || syscall_num == SYSCALL_VFORK ||
            syscall_num == SYSCALL_GET_USER_P || syscall_num == SYSCALL_GET_COW_F ||
            syscall_num == SYSCALL_GETPPID || 
            syscall_num == SYSCALL_END_STRACE) {   // No. of parameters = 0
            if (filep->trace_buffer->W + sizeof(u64) > TRACE_BUFFER_MAX_SIZE) {
                return -EINVAL; // Trace buffer full
            }
            // Write the system call number to the trace buffer
            *(u64 *)(filep->trace_buffer->data + filep->trace_buffer->W) = syscall_num;

            // Update the write pointer
            filep->trace_buffer->W = (filep->trace_buffer->W + sizeof(u64)) % TRACE_BUFFER_MAX_SIZE;
            found = 1;
        } else if (syscall_num == SYSCALL_CLOSE || syscall_num == SYSCALL_EXIT ||
                   syscall_num == SYSCALL_SLEEP || syscall_num == SYSCALL_CONFIGURE ||
                   syscall_num == SYSCALL_DUMP_PTT || syscall_num == SYSCALL_PMAP ||
                   syscall_num == SYSCALL_DUP || syscall_num == SYSCALL_TRACE_BUFFER ||
                   syscall_num == SYSCALL_ALARM) {                                     // No. of parameters = 1
            if (filep->trace_buffer->W + 2 * sizeof(u64) > TRACE_BUFFER_MAX_SIZE) {
                return -EINVAL; // Trace buffer full
            }
            // Write the system call number and parameter 1 to the trace buffer
            *(u64 *)(filep->trace_buffer->data + filep->trace_buffer->W) = syscall_num;
            *(u64 *)(filep->trace_buffer->data + filep->trace_buffer->W + sizeof(u64)) = param1;
            // Update the write pointer
            filep->trace_buffer->W = (filep->trace_buffer->W + 2 * sizeof(u64)) % TRACE_BUFFER_MAX_SIZE;
            found = 1;
        } else if (syscall_num == SYSCALL_EXPAND || 
                   syscall_num == SYSCALL_SIGNAL || syscall_num == SYSCALL_CLONE ||
                   syscall_num == SYSCALL_MUNMAP || syscall_num == SYSCALL_DUP2 ||
                   syscall_num == SYSCALL_STRACE  || 
                   syscall_num == SYSCALL_START_STRACE ) {
               if (filep->trace_buffer->W + 3 * sizeof(u64) > TRACE_BUFFER_MAX_SIZE) {
                return -EINVAL; // Trace buffer full
               }
            // Write the system call number, parameter 1, and parameter 2 to the trace buffer
            *(u64 *)(filep->trace_buffer->data + filep->trace_buffer->W) = syscall_num;
            *(u64 *)(filep->trace_buffer->data + filep->trace_buffer->W + sizeof(u64)) = param1;
            *(u64 *)(filep->trace_buffer->data + filep->trace_buffer->W + 2 * sizeof(u64)) = param2;
            // Update the write pointer
            filep->trace_buffer->W = (filep->trace_buffer->W + 3 * sizeof(u64)) % TRACE_BUFFER_MAX_SIZE;
            found = 1;
        } else if (syscall_num == SYSCALL_READ || syscall_num == SYSCALL_MPROTECT ||
                   syscall_num == SYSCALL_WRITE || syscall_num == SYSCALL_LSEEK ||
                   syscall_num == SYSCALL_READ_STRACE || syscall_num == SYSCALL_READ_FTRACE ||
                   syscall_num == SYSCALL_SHRINK) {   // No. of parameters = 3
            if (filep->trace_buffer->W + 4 * sizeof(u64) > TRACE_BUFFER_MAX_SIZE) {
                return -EINVAL; // Trace buffer full
            }
            // Write the system call number, parameter 1, parameter 2, and parameter 3 to the trace buffer
            *(u64 *)(filep->trace_buffer->data + filep->trace_buffer->W) = syscall_num;
            *(u64 *)(filep->trace_buffer->data + filep->trace_buffer->W + sizeof(u64)) = param1;
            *(u64 *)(filep->trace_buffer->data + filep->trace_buffer->W + 2 * sizeof(u64)) = param2;
            *(u64 *)(filep->trace_buffer->data + filep->trace_buffer->W + 3 * sizeof(u64)) = param3;
            // Update the write pointer
            filep->trace_buffer->W = (filep->trace_buffer->W + 4 * sizeof(u64)) % TRACE_BUFFER_MAX_SIZE;
            found = 1;
        } else if (syscall_num == SYSCALL_MMAP || syscall_num == SYSCALL_FTRACE || 
        	   syscall_num == SYSCALL_OPEN) {                                           // No. of parameters = 4
            if (filep->trace_buffer->W + 5 * sizeof(u64) > TRACE_BUFFER_MAX_SIZE) {
                return -EINVAL; // Trace buffer full
            }
            // Write the system call number, parameter 1, parameter 2, and parameter 3 to the trace buffer
            *(u64 *)(filep->trace_buffer->data + filep->trace_buffer->W) = syscall_num;
            *(u64 *)(filep->trace_buffer->data + filep->trace_buffer->W + sizeof(u64)) = param1;
            *(u64 *)(filep->trace_buffer->data + filep->trace_buffer->W + 2 * sizeof(u64)) = param2;
            *(u64 *)(filep->trace_buffer->data + filep->trace_buffer->W + 3 * sizeof(u64)) = param3;
            *(u64 *)(filep->trace_buffer->data + filep->trace_buffer->W + 4 * sizeof(u64)) = param4;
            // Update the write pointer
            filep->trace_buffer->W = (filep->trace_buffer->W + 5 * sizeof(u64)) % TRACE_BUFFER_MAX_SIZE;
            found = 1;
        }
        if (!found) {
            	return -EINVAL; // The syscall is not in the list of traced system calls
        }
    return 0; // Success
	}
}

int sys_strace(struct exec_context *current, int syscall_num, int action)
{
    if (action == ADD_STRACE) {
        // Add syscall_num to the list of traced system calls
        struct strace_info *new_syscall = (struct strace_info *)os_alloc(sizeof(struct strace_info));
        if (new_syscall == NULL) {
            return -ENOMEM; // Handle memory allocation failure
        }
        new_syscall->syscall_num = syscall_num;
        //new_syscall->next = traced_syscalls;
        //traced_syscalls = new_syscall;
        if(current->st_md_base->next == NULL){
           	current->st_md_base->next = new_syscall;
           	current->st_md_base->last = new_syscall;
        }
        else{
        	current->st_md_base->last->next = new_syscall;
        	current->st_md_base->last = new_syscall;
        }
    } else if (action == REMOVE_STRACE) {
        // Remove syscall_num from the list of traced system calls
        struct strace_info* temp = current->st_md_base->next;
        s32 found = 0;
        while(temp!=NULL){
        	if(temp->syscall_num = syscall_num){
        		found = 1;
        		break;
        	}
        	temp=temp->next;
        }
        if(found == 0){
        	//system call not in list
        	return -EINVAL;
        }
        struct strace_info* temp1 = current->st_md_base->next;
        while(temp1 != NULL){
        	if(temp1->next == temp) break;
        	temp1=temp1->next;
        }
        if(temp1==NULL) //temp is at the head of the list
        {
        	current->st_md_base->next=temp->next;
        	os_free(temp, sizeof(temp));
        	return 0;
        }
        else{
        	temp1->next=temp->next;
        	os_free(temp, sizeof(temp));
        }
        return 0; // System call not found in the traced list
    } else {
        return -EINVAL; // Handle invalid action
    }
    return 0; // On success	
}

int sys_read_strace(struct file *filep, char *buff, u64 count)
{
    s32 i = 0;
    s32 size = 0;
    struct strace_info *curr = traced_syscalls;

    if (count <= 0) {
        return -EINVAL; // Invalid count
    }
    // Check the number of arguments who actually have to write
    while (i < count) {
        // Fill the user buffer with traced system call data
        u64 syscall_number = *(u64 *)(filep->trace_buffer->data + filep->trace_buffer->R);
        int noarg = num_of_arguments(syscall_number);
	
	if(noarg == 0){
		//u64 syscall_number = *(u64 *)(filep->trace_buffer->data + filep->trace_buffer->R);
		filep->trace_buffer->R = (filep->trace_buffer->R + sizeof(u64)) % TRACE_BUFFER_MAX_SIZE;
		
		*(u64 *)buff = syscall_number;
	}
	else if(noarg == 1){
		//u64 syscall_number = *(u64 *)(filep->trace_buffer->data + filep->trace_buffer->R);
		u64 param1 = *(u64 *)(filep->trace_buffer->data + filep->trace_buffer->R + sizeof(u64));
		filep->trace_buffer->R = (filep->trace_buffer->R + 2*sizeof(u64)) % TRACE_BUFFER_MAX_SIZE;
		
		*(u64 *)buff = syscall_number;
        	*(u64 *)(buff + sizeof(u64)) = param1;
	}
	else if(noarg == 2){
		//u64 syscall_number = *(u64 *)(filep->trace_buffer->data + filep->trace_buffer->R);
		u64 param1 = *(u64 *)(filep->trace_buffer->data + filep->trace_buffer->R + sizeof(u64));
		u64 param2 = *(u64 *)(filep->trace_buffer->data + filep->trace_buffer->R + 2 * sizeof(u64));
		filep->trace_buffer->R = (filep->trace_buffer->R + 3*sizeof(u64)) % TRACE_BUFFER_MAX_SIZE;
		
		*(u64 *)buff = syscall_number;
        	*(u64 *)(buff + sizeof(u64)) = param1;
        	*(u64 *)(buff + 2 * sizeof(u64)) = param2;
	}
	else if(noarg == 3){
		//u64 syscall_number = *(u64 *)(filep->trace_buffer->data + filep->trace_buffer->R);
		u64 param1 = *(u64 *)(filep->trace_buffer->data + filep->trace_buffer->R + sizeof(u64));
		u64 param2 = *(u64 *)(filep->trace_buffer->data + filep->trace_buffer->R + 2 * sizeof(u64));
		u64 param3 = *(u64 *)(filep->trace_buffer->data + filep->trace_buffer->R + 3 * sizeof(u64));
		filep->trace_buffer->R = (filep->trace_buffer->R + 4*sizeof(u64)) % TRACE_BUFFER_MAX_SIZE;
		
		*(u64 *)buff = syscall_number;
        	*(u64 *)(buff + sizeof(u64)) = param1;
        	*(u64 *)(buff + 2 * sizeof(u64)) = param2;
        	*(u64 *)(buff + 3 * sizeof(u64)) = param3;
	}
	else if(noarg == 4){
		//u64 syscall_number = *(u64 *)(filep->trace_buffer->data + filep->trace_buffer->R);
		u64 param1 = *(u64 *)(filep->trace_buffer->data + filep->trace_buffer->R + sizeof(u64));
		u64 param2 = *(u64 *)(filep->trace_buffer->data + filep->trace_buffer->R + 2 * sizeof(u64));
		u64 param3 = *(u64 *)(filep->trace_buffer->data + filep->trace_buffer->R + 3 * sizeof(u64));
		u64 param4 = *(u64 *)(filep->trace_buffer->data + filep->trace_buffer->R + 4 * sizeof(u64));
		filep->trace_buffer->R = (filep->trace_buffer->R + 5*sizeof(u64)) % TRACE_BUFFER_MAX_SIZE;
		
		*(u64 *)buff = syscall_number;
        	*(u64 *)(buff + sizeof(u64)) = param1;
        	*(u64 *)(buff + 2 * sizeof(u64)) = param2;
        	*(u64 *)(buff + 3 * sizeof(u64)) = param3;
        	*(u64 *)(buff + 4 * sizeof(u64)) = param4;
	}
	
        buff = buff + (noarg) * sizeof(u64);
        size += (noarg) * sizeof(u64);
        i++;
    }
    return size; // Return the total number of bytes written
}


int sys_start_strace(struct exec_context *current, int fd, int tracing_mode)
{
    if (current == NULL || current->st_md_base == NULL) {
        return -EINVAL; // Invalid data structure
    }
    current->st_md_base->strace_fd = fd;
    current->st_md_base->tracing_mode = tracing_mode;

    if (tracing_mode == FULL_TRACING) {
        current->st_md_base->is_traced = 1; // Enable full tracing
    } else if (tracing_mode == FILTERED_TRACING) {
        current->st_md_base->is_traced = 1;
         // Enable filtered tracing
    } else {
        return -EINVAL; // Handle invalid tracing_mode
    }
    return 0; // On success
}

int sys_end_strace(struct exec_context *current)
{
    if (current == NULL || current->st_md_base == NULL) {
        return -EINVAL; // Invalid data structure
    }
    current->st_md_base->is_traced = 0;
    // Clear the list of traced system calls
    struct strace_info *curr = traced_syscalls;
    while (curr != NULL) {
        struct strace_info *temp = curr;
        curr = curr->next;
        os_free(temp, sizeof(struct strace_info));
    }
    traced_syscalls = NULL;
    return 0; // On success
}



///////////////////////////////////////////////////////////////////////////
//// 		Start of ftrace functionality 		      	      /////
///////////////////////////////////////////////////////////////////////////

long do_ftrace(struct exec_context *ctx, unsigned long faddr, long action, long nargs, int fd_trace_buffer) {
    if (action < ADD_FTRACE || action > DISABLE_BACKTRACE) {
        return -EINVAL; // Invalid action
    }

    struct ftrace_head *ft_head = ctx->ft_md_base;
    
    if (!ft_head) {
        return -EINVAL; // Missing ftrace_head structure
    }

    if (action == ADD_FTRACE) {
        if (ft_head->count >= FTRACE_MAX) {
            return -EINVAL; // Max functions to trace reached
        }

        struct ftrace_info *current = ft_head->next;
        while (current != NULL) {
            if (current->faddr == faddr) {
                return -EINVAL; // Function already in the list
            }
            current = current->next;
        }

        struct ftrace_info *new_info = (struct ftrace_info *)os_alloc(sizeof(struct ftrace_info));
        if (!new_info) {
            return -ENOMEM; // Memory allocation failed
        }

        new_info->faddr = faddr;
        new_info->num_args = nargs;
        new_info->fd = fd_trace_buffer;
        new_info->capture_backtrace = 0; // Disabled by default
        new_info->next = NULL;

        ft_head->count++;
        if (ft_head->next == NULL) {
            ft_head->next = new_info;
            ft_head->last = new_info;
        } else {
            ft_head->last->next = new_info;
            ft_head->last = new_info;
        }
    } else if (action == REMOVE_FTRACE) {
	    struct ftrace_info *current = ft_head->next;
	    struct ftrace_info *prev = NULL; // Initialize prev to NULL
	    while (current != NULL) {
		if (current->faddr == faddr) {
		    if (prev == NULL) {
		        ft_head->next = current->next; // Adjust the head of the list
		    } else {
		        prev->next = current->next;
		    }
		    os_free(current, sizeof(struct ftrace_info));
		    ft_head->count--;
		    return 0;
		}
		prev = current;
		current = current->next;
	    }
	    return -EINVAL; // Function not found in the list
    } else if (action == ENABLE_FTRACE || action == DISABLE_FTRACE) {
        struct ftrace_info *current = ft_head->next;
        while (current != NULL) {
            if (current->faddr == faddr) {
                if (action == ENABLE_FTRACE) {
                    char *code_ptr = (char *)current->faddr;
                    for (int i = 0; i < 4; i++) {
                        current->code_backup[i] = code_ptr[i];
                        code_ptr[i] = INV_OPCODE;
                    }
                } else {
                    char *code_ptr = (char *)current->faddr;
                    for (int i = 0; i < 4; i++) {
                        code_ptr[i] = current->code_backup[i];
                    }
                }
                return 0;
            }
            current = current->next;
        }
        return -EINVAL; // Function not found in the list
    } else if (action == ENABLE_BACKTRACE) {
        struct ftrace_info *current = ft_head->next;
        while (current != NULL) {
            if (current->faddr == faddr) {
                current->capture_backtrace = 1; // Enable backtrace capture
                return 0;
            }
            current = current->next;
        }
        return -EINVAL; // Function not found in the list
    } else if (action == DISABLE_BACKTRACE) {
        struct ftrace_info *current = ft_head->next;
        while (current != NULL) {
            if (current->faddr == faddr) {
                current->capture_backtrace = 0; // Disable backtrace capture
                return 0;
            }
            current = current->next;
        }
        return -EINVAL; // Function not found in the list
    }
    return -EINVAL; // Invalid action
    
}

long handle_ftrace_fault(struct user_regs *regs) {
    
    return 0; // Successfully handled ftrace fault
}
int sys_read_ftrace(struct file *filep, char *buff, u64 count) {
   
    return 0;
}

