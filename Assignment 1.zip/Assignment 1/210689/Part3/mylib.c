#include <stdio.h>
#include <stdlib.h>
#include <sys/mman.h>

#define MIN_CHUNK_SIZE 4 * 1024 * 1024 // Minimum chunk size for memory allocation

// Definition of a linked list structure to manage free memory chunks
struct Chunk {
    unsigned long size;   // Size of the memory chunk
    struct Chunk* next;   // Pointer to the next chunk in the free list
    struct Chunk* prev;   // Pointer to the previous chunk in the free list
};

struct Chunk* free_list_head = NULL; // Head of the free memory chunk list

// Function to allocate memory with a minimum chunk size
void* allocate_memory(size_t size) {
    size_t total_size = size + sizeof(struct Chunk);
    if (total_size < MIN_CHUNK_SIZE)
        total_size = MIN_CHUNK_SIZE;

    // Allocate memory using mmap
    struct Chunk* chunk = (struct Chunk*)mmap(NULL, total_size, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);

    if (chunk == MAP_FAILED) {
        return NULL;
    }

    chunk->size = total_size;
    chunk->next = NULL;
    chunk->prev = NULL;

    return (void*)(chunk + 1); // Return a pointer just after the chunk metadata
}

// Function to add a memory chunk to the free list
void add_to_free_list(struct Chunk* chunk) {
    chunk->next = free_list_head;
    chunk->prev = NULL;
    if (free_list_head) {
        free_list_head->prev = chunk;
    }
    free_list_head = chunk;
}

// Function to remove a memory chunk from the free list
void remove_from_free_list(struct Chunk* chunk) {
    if (chunk->prev) {
        chunk->prev->next = chunk->next;
    } else {
        free_list_head = chunk->next;
    }

    if (chunk->next) {
        chunk->next->prev = chunk->prev;
    }
}

// Function to allocate memory of a specified size
void* memalloc(unsigned long size) {
    if (size == 0) {
        return NULL;
    }

    struct Chunk* current = free_list_head;

    while (current) {
        if (current->size >= size) {
            if (current->size > size) {
                struct Chunk* new_chunk = (struct Chunk*)((char*)current + size);
                new_chunk->size = current->size - size;
                add_to_free_list(new_chunk);
                current->size = size;
            }
            remove_from_free_list(current);

            return (void*)(current + 1); // Return a pointer just after the chunk metadata
        }

        current = current->next;
    }

    return allocate_memory(size); // If no suitable chunk found, allocate new memory
}

// Function to free previously allocated memory
int memfree(void* ptr) {
    if (ptr == NULL) {
        return -1;
    }

    struct Chunk* chunk = (struct Chunk*)((char*)ptr - sizeof(struct Chunk));

    add_to_free_list(chunk);
    return 0;
}
