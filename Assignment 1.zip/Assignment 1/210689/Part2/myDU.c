#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <dirent.h>
#include <unistd.h>
#include <sys/wait.h>
#include <errno.h>

#define MAX_SUBDIRS 100

// Function to calculate the size of a directory and its subdirectories
long long calculateDirectorySize(const char *path) {
    struct stat statbuf;
    if (lstat(path, &statbuf) == -1) {
        if (errno == ENOENT) {
            return 0; // File or directory does not exist
        } else {
            return -1; // Error occurred
        }
    }

    long long totalSize = statbuf.st_size;

    if (S_ISDIR(statbuf.st_mode)) {
        DIR *dir = opendir(path);
        if (dir == NULL) {
            return -1; // Error opening directory
        }

        struct dirent *entry;
        int numSubdirs = 0;
        char subdirPaths[MAX_SUBDIRS][PATH_MAX];

        while ((entry = readdir(dir)) != NULL && numSubdirs < MAX_SUBDIRS) {
            if (strcmp(entry->d_name, ".") == 0 || strcmp(entry->d_name, "..") == 0) {
                continue; // Skip current and parent directories
            }

            snprintf(subdirPaths[numSubdirs], sizeof(subdirPaths[numSubdirs]), "%s/%s", path, entry->d_name);
            numSubdirs++;
        }

        closedir(dir);

        long long subdirSizes[numSubdirs];
        pid_t childPids[numSubdirs];

        for (int i = 0; i < numSubdirs; i++) {
            int pipefd[2];
            if (pipe(pipefd) == -1) {
                return -1; // Error creating pipe
            }

            pid_t pid = fork();

            if (pid == -1) {
                return -1; // Error forking a child process
            } else if (pid == 0) {
                close(pipefd[0]); // Close read end of the pipe in the child process

                long long subdirSize = calculateDirectorySize(subdirPaths[i]);

                if (write(pipefd[1], &subdirSize, sizeof(subdirSize)) == -1) {
                    return -1; // Error writing to the pipe
                }

                close(pipefd[1]);
                exit(EXIT_SUCCESS);
            } else { 
                close(pipefd[1]); // Close write end of the pipe in the parent process

                childPids[i] = pid;
                subdirSizes[i] = 0;

                if (read(pipefd[0], &subdirSizes[i], sizeof(subdirSizes[i])) == -1) {
                    return -1; // Error reading from the pipe
                }

                close(pipefd[0]);
            }
        }

        for (int i = 0; i < numSubdirs; i++) {
            int status;
            while (waitpid(childPids[i], &status, 0) == -1) {
            }
            if (WIFEXITED(status)) {
                totalSize += subdirSizes[i];
            }
        }
    }

    return totalSize;
}

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <relative path to directory>\n", argv[0]);
        return EXIT_FAILURE;
    }

    const char *rootPath = argv[1];
    long long totalSize = calculateDirectorySize(rootPath);

    if (totalSize == -1) {
        fprintf(stderr, "Unable to execute\n");
        return EXIT_FAILURE;
    }

    printf("%lld\n", totalSize);

    return EXIT_SUCCESS;
}