#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

int main(int argc, char *argv[]) {
    // Check if there are at least two command-line arguments
    if (argc < 2) {
        fprintf(stderr, "Usage: %s <executable> <non-negative integer>\n", argv[0]);
        return 1; // Return error code 1
    }
    // Convert the last argument (number) to an unsigned long and calculate result
    unsigned long num = strtoul(argv[argc - 1], NULL, 10);
    unsigned long result = num * 2;
    // Handle different cases based on the number of arguments
    if (argc == 2) {
        // If there are only two arguments, print the result
        printf("%lu\n", result);
    } 
    else if (argc == 3) {
        // If there are three arguments, execute another program with the result
        char *next_executable = argv[1];
        char result_str[20]; // Buffer for converting the result to a string
        sprintf(result_str, "%lu", result);
        char next_executable_path[255]; // Buffer for the path to the next executable
        snprintf(next_executable_path, sizeof(next_executable_path), "./%s", next_executable);
        char *args[] = {next_executable_path, result_str, NULL};
        // Execute the next program with the result as an argument
        execvp(next_executable_path, args);
        perror("execvp"); // Print an error message if execvp fails
        return 1; // Return error code 1
    }
    return 0; // Return success code 0
}
