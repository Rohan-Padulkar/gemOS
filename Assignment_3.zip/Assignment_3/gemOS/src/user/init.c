#include<ulib.h>

int main(u64 arg1, u64 arg2, u64 arg3, u64 arg4, u64 arg5)
{
  printf("#T1\n");
  int pages = 4096;
	
  // vm_area will be created without physical pages.
  char * lazy_alloc = mmap(NULL, pages*50, PROT_READ|PROT_WRITE, 0);
  if((long)lazy_alloc < 0)
  {
    // Testcase failed.
    printf("#T2\n");
    printf("Test case failed \n");
    return 1;
  }
  printf("#T3\n");
  // All accesses should result in page fault.
  for(int i = 0; i<50; i++)
  {
    lazy_alloc[(pages * i)] = 'X';
  }
	printf("#T4\n");
  // Number of MMAP_Page_Faults should be 50 & 
  // Number of vm_area should 1
  pmap(0);

  for(int i = 0; i<50; i++)
  {
    // Reading the value from physical page. It should be same as written
    if(lazy_alloc[(pages * i)] != 'X')
    {
      printf("#T5\n");
      // Testcase Failed;
      printf("Test case failed \n");
      return 0;
    }
  }
  printf("#T6\n");
  // Number of MMAP_Page_Faults should be 50 & 
  // Number of vm_area should 1
  pmap(0);

 return 0;
}
