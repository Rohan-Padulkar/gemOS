#include <types.h>
#include <mmap.h>
#include <fork.h>
#include <v2p.h>
#include <page.h>

/* 
 * You may define macros and other helper functions here
 * You must not declare and use any static/global variables 
 * */

#define ROUND_DOWN(x, s) (((x) / (s)) * (s))
#define ROUND_UP(x, s)   ((((x) + (s) - 1) / (s)) * (s))

// Helper function to find an available address for mapping
u64 find_available_address(struct exec_context *current, int length) {
    u64 start_addr = MMAP_AREA_START;
    u64 end_addr = MMAP_AREA_END;

    struct vm_area *vma = current->vm_area;

    if (!vma) {
        // No existing VMAs, so there's space at the beginning
        return start_addr;
    }
    // Iterate through the existing VMAs to find an available space
    while (vma->vm_next) {
        u64 current_end = vma->vm_end;
        u64 next_start = vma->vm_next->vm_start;
        if (next_start - current_end >= length) {
            // Found sufficient space between two VMAs
            return current_end;
        }
        vma = vma->vm_next;
    }
    // Check if there's space between the last VMA and the end of the mmap area
    if (end_addr - vma->vm_end >= length) {
        return vma->vm_end;
    }
    if (end_addr - vma->vm_end < length) {
        //printk("#NO SPACE\n");
    }
    if (end_addr == vma->vm_end) {
        //printk("#EQUAL\n");
    }
    // No space available
    return -1;
}

/**
 * mprotect System call Implementation.
 */

// Assuming the create_vm_area function is declared correctly in mmap.h
// extern struct vm_area* create_vm_area(u64 start_addr, u64 end_addr, u32 flags, int access_flags);

long vm_area_mprotect(struct exec_context *cur, u64 addr, int len, int prot) {
    len = (len % PAGE_SIZE) ? ((len / PAGE_SIZE) + 1) * PAGE_SIZE : len;
    if ((addr < MMAP_AREA_START) || ((addr + len) > MMAP_AREA_END))
        return -1;

    int result = 0;
    if (prot == PROT_WRITE)
        prot = PROT_READ | PROT_WRITE;

    if (cur->vm_area->vm_next == NULL)
        return -1;

    struct vm_area *current_area = cur->vm_area->vm_next;
    struct vm_area *prev_area = cur->vm_area;

    while (current_area != NULL) {
        if (addr <= current_area->vm_start && current_area->vm_end <= addr + len) {
            current_area->access_flags = prot;
            prev_area = current_area;
            current_area = current_area->vm_next;
        } else if (addr <= current_area->vm_start && current_area->vm_start < addr + len) {
            stats->num_vm_area++;
            if (stats->num_vm_area > 128)
                return -1;

            struct vm_area *new_area = os_alloc(sizeof(struct vm_area));
            new_area->vm_start = current_area->vm_start;
            new_area->vm_end = addr + len;
            new_area->access_flags = prot;

            prev_area->vm_next = new_area;
            current_area->vm_start = addr + len;
            new_area->vm_next = current_area;
            prev_area = current_area;
            current_area = current_area->vm_next;
        } else if (addr > current_area->vm_start && current_area->vm_end > addr + len) {
            stats->num_vm_area += 2;
            if (stats->num_vm_area > 128)
                return -1;

            struct vm_area *new_area1 = os_alloc(sizeof(struct vm_area));
            struct vm_area *new_area2 = os_alloc(sizeof(struct vm_area));

            new_area1->vm_start = addr + len;
            new_area1->vm_end = current_area->vm_end;
            new_area1->vm_next = current_area->vm_next;
            new_area1->access_flags = current_area->access_flags;

            new_area2->vm_start = addr;
            new_area2->vm_end = addr + len;
            new_area2->vm_next = new_area1;
            new_area2->access_flags = prot;

            current_area->vm_end = addr;
            current_area->vm_next = new_area2;

            prev_area = new_area1;
            current_area = new_area1->vm_next;
        } else if (addr > current_area->vm_start && current_area->vm_end > addr) {
            stats->num_vm_area++;
            if (stats->num_vm_area > 128)
                return -1;

            struct vm_area *new_area = os_alloc(sizeof(struct vm_area));
            new_area->vm_start = addr;
            new_area->vm_end = current_area->vm_end;
            new_area->access_flags = prot;

            current_area->vm_end = addr;
            new_area->vm_next = current_area->vm_next;
            current_area->vm_next = new_area;

            prev_area = new_area;
            current_area = new_area->vm_next;
        } else {
            prev_area = current_area;
            current_area = current_area->vm_next;
        }
    }

    current_area = cur->vm_area;
    prev_area = NULL;

    while (current_area != NULL) {
        if (prev_area != NULL) {
            if (prev_area->vm_end == current_area->vm_start && prev_area->access_flags == current_area->access_flags) {
                prev_area->vm_end = current_area->vm_end;
                prev_area->vm_next = current_area->vm_next;
                os_free(current_area, sizeof(struct vm_area));
                stats->num_vm_area--;
                current_area = prev_area->vm_next;
                continue;
            }
        }
        prev_area = current_area;
        current_area = current_area->vm_next;
    }

    return result;
}

/**
 * mmap system call implementation.
 */
 
long vm_area_map(struct exec_context *current, u64 addr, int length, int prot, int flags) {
    // Create a dummy node as the first VMA
    if (current->vm_area == NULL) {
        u64 dummy_size = 4 * 1024;  // Set the size to 4KB
        current->vm_area = create_vm_area(MMAP_AREA_START, MMAP_AREA_START + dummy_size, 0);
        current->vm_area->vm_next = NULL;
        //stats->num_vm_area++;
    }

    // Check for invalid arguments and fail if necessary
    if (length <= 0 || (prot != PROT_READ && prot != (PROT_READ | PROT_WRITE))) {
        return -1;
    }

    // Choose the starting address based on addr or find an available address
    u64 start_addr = (addr ? (u64)addr : find_available_address(current, length));

    // Calculate the number of pages needed based on the given length
    int num_pages = (length + PAGE_SIZE - 1) / PAGE_SIZE;

    // Iterate through the linked list of VMAs to find the correct position
    struct vm_area *prev = current->vm_area;
    struct vm_area *current_vma = prev->vm_next;

    while (current_vma) {
        // Check if the new VMA can be merged with the current one
        if (current_vma->vm_end == start_addr && current_vma->access_flags == prot) {
            // Merge VMAs
            current_vma->vm_end += num_pages * PAGE_SIZE;
            return start_addr;
        }

        // Check if the new VMA should be inserted before the current one
        if (start_addr + num_pages * PAGE_SIZE <= current_vma->vm_start) {
            prev->vm_next = create_vm_area(start_addr, start_addr + num_pages * PAGE_SIZE, prot);
            prev->vm_next->vm_next = current_vma;

            // Check if the new VMA can be merged with the next one
            if (current_vma->vm_start == prev->vm_next->vm_end && current_vma->access_flags == prot) {
                // Merge VMAs
                prev->vm_next->vm_end = current_vma->vm_end;
                prev->vm_next->vm_next = current_vma->vm_next;
                os_free(current_vma, sizeof(struct vm_area));
                // Adjust the count as merging occurred
                stats->num_vm_area--;
            }

            return start_addr;
        }

        prev = current_vma;
        current_vma = prev->vm_next;
    }

    // If we reach here, the new VMA is not merged and is appended to the end
    prev->vm_next = create_vm_area(start_addr, start_addr + num_pages * PAGE_SIZE, prot);
    // Adjust the count as merging didn't occur
    //stats->num_vm_area++;

    return start_addr;
}

/**
 * munmap system call implemenations
 */

//original
long vm_area_unmap(struct exec_context *current, u64 addr, int length) {
    if (length <= 0)
        return -1;

    struct vm_area *prev = NULL;
    struct vm_area *vma = current->vm_area;

    while (vma) {
        if (vma->vm_end > addr && vma->vm_start < addr + length) {
            // Align the start of the unmapping operation to the beginning of the page
            u64 page_start = ROUND_DOWN(addr, PAGE_SIZE);
            // Align the end of the unmapping operation to the end of the page
            u64 page_end = ROUND_UP(addr + length, PAGE_SIZE);

            if (vma->vm_start >= page_start && vma->vm_end <= page_end) {
                // Remove the entire VMA
                if (prev)
                    prev->vm_next = vma->vm_next;
                else
                    current->vm_area = vma->vm_next;
		stats->num_vm_area--;
                os_free(vma, sizeof(struct vm_area));
            } else {
                if (vma->vm_start >= page_start) {
                    // Adjust the VMA's start to the end of the page
                    vma->vm_start = page_end;
                } else if (vma->vm_end <= page_end) {
                    // Remove the VMA and adjust the pointers
                    if (prev)
                        prev->vm_next = vma->vm_next;
                    else
                        current->vm_area = vma->vm_next;

                    struct vm_area *temp = vma;
                    stats->num_vm_area--;
                    vma = vma->vm_next;
                    os_free(temp, sizeof(struct vm_area));
                } else {
                    // Split the VMA into two, aligning the end of the first part to the end of the page
                    struct vm_area *new_vma = os_alloc(sizeof(struct vm_area));
                    new_vma->vm_start = page_end;
                    new_vma->vm_end = vma->vm_end;
                    new_vma->access_flags = vma->access_flags;
                    new_vma->vm_next = vma->vm_next;
                    vma->vm_end = page_start;
                    vma->vm_next = new_vma;
                    stats->num_vm_area++;
                }
            }
        }
        prev = vma;
        vma = vma->vm_next;
    }
    return 0;
}

/**
 * Function will invoked whenever there is page fault for an address in the vm area region
 * created using mmap
 */

long vm_area_pagefault(struct exec_context *current, u64 addr, int error_code) {
   
    return 0;
}

/**
 * cfork system call implemenations
 * The parent returns the pid of child process. The return path of
 * the child process is handled separately through the calls at the 
 * end of this function (e.g., setup_child_context etc.)
 */

long do_cfork(){
    u32 pid;
    struct exec_context *new_ctx = get_new_ctx();
    struct exec_context *ctx = get_current_ctx();
     /* Do not modify above lines
     * 
     * */   
     /*--------------------- Your code [start]---------------*/
     

     /*--------------------- Your code [end] ----------------*/
    
     /*
     * The remaining part must not be changed
     */
    copy_os_pts(ctx->pgd, new_ctx->pgd);
    do_file_fork(new_ctx);
    setup_child_context(new_ctx);
    return pid;
}



/* Cow fault handling, for the entire user address space
 * For address belonging to memory segments (i.e., stack, data) 
 * it is called when there is a CoW violation in these areas. 
 *
 * For vm areas, your fault handler 'vm_area_pagefault'
 * should invoke this function
 * */

long handle_cow_fault(struct exec_context *current, u64 vaddr, int access_flags)
{
  return -1;
}
